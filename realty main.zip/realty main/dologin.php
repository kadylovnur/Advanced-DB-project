<?php 

session_start();
require 'config.php';


if(isset($_POST['sendlogin'])){

$admin_username=$_POST['number'];
$admin_password=$_POST['password'];

$admin_username = stripslashes($admin_username);
$admin_password = stripslashes($admin_password);
$sql="select * from users where login='".$admin_username."'AND password='".$admin_password."'";
   
    
$stid=oci_parse($conn,$sql);
$exec = oci_execute($stid);
//  $message = oci_fetch_all($stid,$res);
//  echo "<script type='text/javascript'>alert('$message');</script>";
if(oci_fetch_all($stid,$res)==1){
 
  $_SESSION['User'] = $admin_username;
  header("locaton:index.php");

}else{
  $message = "incorrect password or username";
  echo "<script type='text/javascript'>alert('$message');</script>";
  header("location:signin.php");
}


// else
// header("location:signin.php");
// while (($row = oci_fetch_array($stid, OCI_ASSOC)) != false) {

//     $pass=$row['PASSWORD'];
    
//     $name=$row['NAME'];
//     $username=$row['LOGIN'];

//     if($admin_username==$username and $admin_password==$pass){
      
//  $_SESSION['login']=$username;
   
// }

// else{
// $message = "wrong answer";
// echo "<script type='text/javascript'>alert('$message');</script>";
// }





//         break;

// }
// echo "<center><h1 style=#55555>Wrong Username or Password</h1></center>";



 }
 header("locaton:index.php");

  
?>