<?php 
require 'config.php';
session_start();
if(!isset($_SESSION['User'])){
   header("Location:signin.php");
}
?>
 <!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">    
    <title>Home Property | Profile</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
    
    <!-- Font awesome -->
    <link href="css/font-awesome.css" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="css/bootstrap.css" rel="stylesheet">   
    <!-- slick slider -->
    <link rel="stylesheet" type="text/css" href="css/slick.css">
    <!-- price picker slider -->
    <link rel="stylesheet" type="text/css" href="css/nouislider.css">
    <!-- Fancybox slider -->
    <link rel="stylesheet" href="css/jquery.fancybox.css" type="text/css" media="screen" /> 
    <!-- Theme color -->
    <link id="switcher" href="css/theme-color/default-theme.css" rel="stylesheet">     

    <!-- Main style sheet -->
    <link href="css/style.css" rel="stylesheet">    

   
    <!-- Google Font -->
    <link href='https://fonts.googleapis.com/css?family=Vollkorn' rel='stylesheet' type='text/css'>    
    <link href='https://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
    

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  

  </head>
  <body>
  <!-- Pre Loader -->
  <div id="aa-preloader-area">
    <div class="pulse"></div>
  </div>
  <!-- SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#"><i class="fa fa-angle-double-up"></i></a>
  <!-- END SCROLL TOP BUTTON -->


  <!-- Start header section -->
  <header id="aa-header">  
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="aa-header-area">
            <div class="row">
              <div class="col-md-6 col-sm-6 col-xs-6">
                <div class="aa-header-left">
                  <div class="aa-telephone-no">
                    <span class="fa fa-phone"></span>
                    +7 (727) 307 95 65
                  </div>
                  <div class="aa-email hidden-xs">
                    <span class="fa fa-envelope-o"></span> info@sdu.edu.kz​
                  </div>
                </div>              
              </div>
              <div class="col-md-6 col-sm-6 col-xs-6">
                <div class="aa-header-right">
                
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </header>
  <!-- End header section -->
  <!-- Start menu section -->
  <section id="aa-menu-area">
    <nav class="navbar navbar-default main-navbar" role="navigation">  
      <div class="container">
        <div class="navbar-header">
          <!-- FOR MOBILE VIEW COLLAPSED BUTTON -->
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <!-- LOGO -->                                               
          <!-- Text based logo -->
          <a class="navbar-brand aa-logo" href="index.php"> Realty</a>
          <!-- Image based logo -->
          <!-- <a class="navbar-brand aa-logo-img" href="index.html"><img src="img/logo.png" alt="logo"></a> -->                     
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul id="top-menu" class="nav navbar-nav navbar-right aa-main-nav">
            <li><a href="index.php">HOME</a></li>
             <li class="dropdown">
              <a class="dropdown-toggle" data-toggle="dropdown" href="properties.html">PROPERTIES <span class="caret"></span></a>
              <ul class="dropdown-menu" role="menu">                
                <li><a href="properties.html">PROPERTIES</a></li>
                <li><a href="properties-detail.html">PROPERTIES DETAIL</a></li>                                            
              </ul>
            </li>
            
            <li><a href="contact.html">CONTACT</a></li>
            <li class="active"><a href="#">PROFILE</a></li>
            <!-- <li class="dropdown">
              <a class="dropdown-toggle" data-toggle="dropdown" href="#">PAGES <span class="caret"></span></a>
              <ul class="dropdown-menu" role="menu">                
                <li><a href="properties-detail.html">PRODUCT DETAILS</a></li>
                <li><a href="blog-single.html">BLOG DETAILS</a></li>                
                <li class="active"><a href="404.html">404 PAGE</a></li>                
              </ul>
            </li> -->
          </ul>                          
        </div><!--/.nav-collapse -->       
      </div>          
    </nav> 
  </section>
  <!-- End menu section -->

  <!-- Start Proerty header  -->
  <section id="aa-property-header">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="aa-property-header-inner">
            <h2>PROFILE</h2>
            <ol class="breadcrumb">
            <li><a href="#">HOME</a></li>            
            <li class="active">PROFILE</li>
          </ol>
          </div>
        </div>
      </div>
    </div>
  </section> 
  <!-- End Proerty header  -->
  <div class="container bootstrap snippet">
    <div class="row">
      <div class="col-sm-3"><!--left col-->
              

      <div class="text-center">
        <img src="http://ssl.gstatic.com/accounts/ui/avatar_2x.png" class="avatar img-circle img-thumbnail" alt="avatar">
        <h6>Upload a different photo...</h6>
        <input type="file" class="text-center center-block file-upload">
      </div></hr><br>

               
          <div class="panel panel-default">
            <div class="panel-heading">Личные данные</div>
            <div class="panel-body">
              <?php
              $stid = oci_parse($conn,"select * from users where login = '".$_SESSION['User']."'");
              oci_execute($stid); 
              while (($row = oci_fetch_assoc($stid)) != false) {
                $fullname = $row['NAME'];
                $login = $_SESSION['User'];
                $fullname = 'Gaukhar';
                $login = 87079878890	;
              echo "
              <h4 class = 'name'>$fullname</h4>
              <h4 class = 'name'>$login</h4>
              ";}
              ?>
              
            </div>
          </div>
          
        </div><!--/col-3-->
      <div class="col-sm-9">
            <ul class="nav nav-tabs">
                <li class="active"><a data-toggle="tab" href="#home">My announcements</a></li>
                <li><a data-toggle="tab" href="#settings">Settings</a></li>
                <li><a data-toggle="tab" href="#new">New</a></li>
              </ul>

              
          <div class="tab-content">
            <div class="tab-pane active" id="home">
                <!-- Start Properties  -->
  <section id="aa-properties">
    <div class="container">
      <div class="row">
        <div class="col-md-8">
          <div class="aa-properties-content">
            <!-- start properties content head -->
            <div class="aa-properties-content-head">              
              <div class="aa-properties-content-head-left">
                <form action="" class="aa-sort-form">
                  <label for="">Sort by</label>
                  <select name="">
                    <option value="1" selected="Default">Default</option>
                    <option value="2">Name</option>
                    <option value="3">Price</option>
                    <option value="4">Date</option>
                  </select>
                </form>
                <form action="" class="aa-show-form">
                  <label for="">Show</label>
                  <select name="">
                    <option value="1" selected="12">6</option>
                    <option value="2">12</option>
                    <option value="3">24</option>
                  </select>
                </form>
              </div>
              <div class="aa-properties-content-head-right">
                <a id="aa-grid-properties" href="#"><span class="fa fa-th"></span></a>
                <a id="aa-list-properties" href="#"><span class="fa fa-list"></span></a>
              </div>            
            </div>
            <!-- Start properties content body -->
            <div class="aa-properties-content-body">
              <ul class="aa-properties-nav">
              
              <li>
              <?php
           
          
           $info = "select * from home where login = '".$_SESSION['User']."' order by homeid";
          

            $stid=oci_parse($conn,$info);
            oci_execute($stid);

         //   $nrows = oci_fetch_all($stid, $res, null, null, OCI_FETCHSTATEMENT_BY_ROW);

         $i =0;
            while (($row = oci_fetch_assoc($stid)) != false) {
              $address=$row['ADDRESS'];
              $price = $row['COST'];
              $floor = $row['FLOOR'];
              $type = $row['TYPEID'];
              $rooms = $row['ROOMS'];
              $area = $row['AREA'];
              $description = $row['DESCRIPTION']->load();
              $_SESSION['homeid'] = $row['HOMEID'];
              $array[] = $row['HOMEID'];
              echo"
                  <article class='aa-properties-item'>
                    <a class='aa-properties-item-img' href='properties-detail.php?homid=$array[$i]'>
                      <img alt='img' src='img/item/6.jpg'>
                    </a>
                    <div class='aa-tag for-rent'>
                      For Selling
                    </div>
                    <div class='aa-properties-item-content'>
                      <div class='aa-properties-info'>
                        <span>$rooms Rooms</span>
                        <span>$area area</span>
                        <span>$floor floor</span>
                        
                      </div>
                      <div class='aa-properties-about'>
                        <h3><a href='#'>$address</a></h3>
                        <p>$description</p>                      
                      </div>
                      <div class='aa-properties-detial'>
                        <span class='aa-price'>
                          $price Tenge
                        </span>
                        <a class='aa-secondary-btn' href='#'>View Details</a>
                      </div>
                    </div>
                  </article>";
                  $i=$i+1;
                }

                  ?>
                </li>
              </ul>
            </div>
            <!-- Start properties content bottom -->
            <div class="aa-properties-content-bottom">
              <nav>
                <ul class="pagination">
                  <li>
                    <a href="#" aria-label="Previous">
                      <span aria-hidden="true">&laquo;</span>
                    </a>
                  </li>
                  <li><a href="#">1</a></li>
                  <li><a href="#">2</a></li>
                  <li class="active"><a href="#">3</a></li>
                  <li><a href="#">4</a></li>
                  <li><a href="#">5</a></li>
                  <li>
                    <a href="#" aria-label="Next">
                      <span aria-hidden="true">&raquo;</span>
                    </a>
                  </li>
                </ul>
              </nav>
            </div>
          </div>
        </div></div></div>
              
              <hr>
              
             </div><!--/tab-pane-->
             
             <div class="tab-pane" id="settings">
                
                
                  <hr>
                  <form class="form" action="profile.php" method="POST" id="registrationForm">
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                              <label for="first_name"><h4>Name</h4></label>
                              <input type="text" class="form-control" name="first_name" id="first_name" placeholder="first name" title="enter your first name if any.">
                          </div>
                      </div>
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                              <label for="phone"><h4>Phone</h4></label>
                              <input type="text" class="form-control" name="phone" id="phone" placeholder="enter phone" title="enter your phone number if any.">
                          </div>
                      </div>
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                              <label for="password"><h4>Password</h4></label>
                              <input type="password" class="form-control" name="password" id="password" placeholder="password" title="enter your password.">
                          </div>
                      </div>
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                            <label for="password2"><h4>Verify</h4></label>
                              <input type="password" class="form-control" name="password2" id="password2" placeholder="password2" title="enter your password2.">
                          </div>
                      </div>
                      <div class="form-group">
                           <div class="col-xs-12">
                                <br>
                                <button class="btn btn-lg btn-success pull-right" type="submit"><i class="glyphicon glyphicon-ok-sign"></i> Save</button>
                                <!--<button class="btn btn-lg" type="reset"><i class="glyphicon glyphicon-repeat"></i> Reset</button>-->
                            </div>
                      </div>
                </form>
              </div>

               <div class="tab-pane" id="new">
                <?php
                $newhomeid ='select max(homeid)+1 mx from home';
               
            $std=oci_parse($conn,$newhomeid);
            oci_execute($std);

         //   $nrows = oci_fetch_all($stid, $res, null, null, OCI_FETCHSTATEMENT_BY_ROW);


            while (($row = oci_fetch_assoc($std)) != false) {
              $sethomeid = $row['MX'];

                if(isset($_POST['submit'])){
                  $ins = "insert into home(homeid,rooms,address,cost,floor,Area,Description,login,cityid,typeid) values($sethomeid,'".$_POST['rooms']."','".$_POST['address']."','".$_POST['cost']."'
                  ,'".$_POST['floor']."','".$_POST['area']."','".$_POST['description']."' ,'".$_SESSION['User']."','nur','sec')";
                  $inse = oci_parse($conn,$ins);
                 $exec = oci_execute($inse);}
                }
                header("Refresh:0");
                ?>
                
                  <hr>
                  <form class="form" action="profile.php" method="post" id="registrationForm">
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                              <label for="rooms"><h4>Rooms</h4></label>
                              <input type="text" class="form-control" name="rooms" id="rooms" placeholder="rooms" title="enter how many rooms.">
                          </div>

                      </div>    
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                              <label for="address"><h4>Address</h4></label>
                              <input type="text" class="form-control" name="address" id="address" placeholder="address" title="enter address.">
                          </div> 
                          <div class="col-xs-6">
                              <label for="cost"><h4>Cost</h4></label>
                              <input type="text" class="form-control" name="cost" id="cost" placeholder="enter cost" title="enter cost.">
                          </div>
                      </div>
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                              <label for="floor"><h4>Floor</h4></label>
                              <input type="floor" class="form-control" name="floor" id="floor" placeholder="password" title="enter floor.">
                          </div>
                      </div>
                      <div class="form-group">
                          
                          <div class="col-xs-6">
                            <label for="area"><h4>Area</h4></label>
                              <input type="area" class="form-control" name="area" id="area" placeholder="area" title="enter area">
                          </div>
                       <div class="form-group">
                          
                          <div class="col-xs-6">
                            <label for="city"><h4>City</h4></label>
                              <select type="city" name = "city" class="form-control search-slt" id="city" placeholder="city" title="select one">
                                <option>City</option>
                                <option>Nur-Sultan</option>
                                <option>Kyzylorda</option>
                                
                              </select>
                          </div>
                        </div>

                          <div class="form-group">
                          
                          <div class="col-xs-6">
                            <label for="type"><h4>Type</h4></label>
                              <select type="type" class="form-control search-slt" id="type" placeholder="type" title="select one">
                                <option>Type</option>
                                <option>Example one</option>
                                <option>Example one</option>
                                <option>Example one</option>
                                <option>Example one</option>
                                <option>Example one</option>
                                <option>Example one</option>
                              </select>
                          </div>
                        </div>

                          <div class="form-group">
                          <div class="col-xs-6">
                            <div class="form-group">
                            <label for="Video"><h4>Video</h4></label>
                            <input type="file" class="form-control-file" id="video">
                          </div>

                          <div class="form-group row">
                          <div class="col-xs-12">
                            <label for="description"><h4>Description</h4></label>
                            <textarea name = "description" class="form-control" id="exampleFormControlTextarea1" ></textarea>
                          </div>
                        </div>

                          <div class="form-group">
                           <div class="col-xs-12">
                                <br>
                                <button class="btn btn-lg btn-success pull-right" name = "submit"type="submit"><i class="glyphicon glyphicon-ok-sign"></i> Save</button>
                                <!--<button class="btn btn-lg" type="reset"><i class="glyphicon glyphicon-repeat"></i> Reset</button>-->
                            </div>
                      </div>
                </form>
              </div>
               
              </div><!--/tab-pane-->
          </div><!--/tab-content-->

        </div><!--/col-9-->
    </div><!--/row-->


  <!-- Footer -->
  <footer id="aa-footer">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
        <div class="aa-footer-area">
          <div class="row">
            <div class="col-md-3 col-sm-6 col-xs-12">
              <div class="aa-footer-left">
               
              </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-12">
              <div class="aa-footer-middle">
                <a href="#"><i class="fa fa-facebook"></i></a>
                <a href="#"><i class="fa fa-twitter"></i></a>
                <a href="#"><i class="fa fa-google-plus"></i></a>
                <a href="#"><i class="fa fa-youtube"></i></a>
              </div>
            </div>
            <div class="col-md-6 col-sm-12 col-xs-12">
              <div class="aa-footer-right">
                <a href="#">Home</a>
                <a href="#">Support</a>
                <a href="#">License</a>
                <a href="#">FAQ</a>
                <a href="#">Privacy & Term</a>
              </div>
            </div>            
          </div>
        </div>
      </div>
      </div>
    </div>
  </footer>
  <!-- / Footer -->

  <!-- jQuery library -->
  <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script> -->
  <script src="js/jquery.min.js"></script>   
  <!-- Include all compiled plugins (below), or include individual files as needed -->
  <script src="js/bootstrap.js"></script>   
  <!-- slick slider -->
  <script type="text/javascript" src="js/slick.js"></script>
  <!-- Price picker slider -->
  <script type="text/javascript" src="js/nouislider.js"></script>
   <!-- mixit slider -->
  <script type="text/javascript" src="js/jquery.mixitup.js"></script>
  <!-- Add fancyBox -->        
  <script type="text/javascript" src="js/jquery.fancybox.pack.js"></script>
  <!-- Custom js -->
  <script src="js/custom.js"></script> 
  
  </body>
</html>