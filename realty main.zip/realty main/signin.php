



<?php 

session_start();
require 'config.php';


if(isset($_POST['sendlogin'])){

$admin_username=$_POST['number'];
$admin_password=$_POST['password'];

$admin_username = stripslashes($admin_username);
$admin_password = stripslashes($admin_password);
$sql=$db->query("select * from users where login='".$admin_username."'AND password='".$admin_password."'");
$_SESSION['User'] = $admin_username;
echo "<script type='text/javascript'>alert('".$_SESSION['User']."');</script>";
header("locaton:index.php");  
    

//  $message = oci_fetch_all($stid,$res);
//  echo "<script type='text/javascript'>alert('$message');</script>";
if($sql->fetchArray(SQLITE3_ASSOC)){
  $message = "correct password";
  echo "<script type='text/javascript'>alert('$message');</script>";

  $_SESSION['User'] = $admin_username;
  header("locaton:index.php");

}else{
  $message = "incorrect password or username";
  echo "<script type='text/javascript'>alert('$message');</script>";
  header("location:signin.php");
}


// else
// header("location:signin.php");
// while (($row = oci_fetch_array($stid, OCI_ASSOC)) != false) {

//     $pass=$row['PASSWORD'];
    
//     $name=$row['NAME'];
//     $username=$row['LOGIN'];

//     if($admin_username==$username and $admin_password==$pass){
      
//  $_SESSION['login']=$username;
   
// }

// else{
// $message = "wrong answer";
// echo "<script type='text/javascript'>alert('$message');</script>";
// }





//         break;

// }
// echo "<center><h1 style=#55555>Wrong Username or Password</h1></center>";



 }


  
?>



<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">    
    <title>Home Property | Signin</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
    
    
    <!-- Font awesome -->
    <link href="css/font-awesome.css" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="css/bootstrap.css" rel="stylesheet">   
    <!-- slick slider -->
    <link rel="stylesheet" type="text/css" href="css/slick.css">
    <!-- price picker slider -->
    <link rel="stylesheet" type="text/css" href="css/nouislider.css">
    <!-- Fancybox slider -->
    <link rel="stylesheet" href="css/jquery.fancybox.css" type="text/css" media="screen" /> 
    <!-- Theme color -->
    <link id="switcher" href="css/theme-color/default-theme.css" rel="stylesheet">     

    <!-- Main style sheet -->
    <link href="css/style.css" rel="stylesheet">    

   
    <!-- Google Font -->
    <link href='https://fonts.googleapis.com/css?family=Vollkorn' rel='stylesheet' type='text/css'>    
    <link href='https://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
    

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  

  </head>
  <body>
  <section id="aa-signin">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="aa-signin-area">
            <div class="aa-signin-form">
              <div class="aa-signin-form-title">
                <a class="aa-property-home" href="index.html">Property Home</a>
                <h4>Sign in to your account</h4>
              </div>
              <form class="contactform" method="POST" action="index.php">                                                 
                <div class="aa-single-field">
                  <label for="number">Phone number <span class="required">*</span></label>
                  <input type="number" required="required" aria-required="true" value="" name="number">
                </div>
                <div class="aa-single-field">
                  <label for="password">Password <span class="required">*</span></label>
                  <input type="password" name="password"> 
                </div>
                <div class="aa-single-field">
                <label>
                  <input type="checkbox"> Remember me
                </label>                                                          
                </div> 
                <div class="aa-single-submit">
                  <input type="submit" value="Send Message" class="aa-browse-btn" name="sendlogin">  
                  <p>Don't Have A Account Yet? <a href="register.html">CREATE NOW!</a></p>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  
  <!-- jQuery library -->
  <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script> -->
  <script src="js/jquery.min.js"></script>   
  <!-- Include all compiled plugins (below), or include individual files as needed -->
  <script src="js/bootstrap.js"></script>   
  <!-- slick slider -->
  <script type="text/javascript" src="js/slick.js"></script>
  <!-- Price picker slider -->
  <script type="text/javascript" src="js/nouislider.js"></script>
   <!-- mixit slider -->
  <script type="text/javascript" src="js/jquery.mixitup.js"></script>
  <!-- Add fancyBox -->        
  <script type="text/javascript" src="js/jquery.fancybox.pack.js"></script>
  <!-- Custom js -->
  <script src="js/custom.js"></script> 
  
  </body>
</html>