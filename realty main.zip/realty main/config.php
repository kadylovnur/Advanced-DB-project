<?php
class MyDB extends SQLite3
{
    function __construct()
    {
        $this->open('C:\realty\realty.sqlite');
    }
}

$db = new MyDB();


// $homes = $db->query('select * from home');
// $i =0;
// while ($row = $homes->fetchArray(SQLITE3_ASSOC)) {
//     $address = $row['cityID'];
//     print($address);
// }
?>